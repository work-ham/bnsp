<html>
<body>
<!-- Nama : Ahmad Ilham Kushartanto
    NPM: 207064516072
    Prodi: Informatika-->
    <table border="0">
    <?php
    if (isset($_POST['submit'])) {
    $nama = $_POST['aslab'];
    $nama_lab = $_POST['lab'];
    $prodi = $_POST['prodi'];
    ?>
        <tr>
            <td>Nama Lab Anda Adalah: </td>
            <td><b>
            <font color=blue>
                    <?php echo $nama_lab ?>
                </b>
            </font>
            </td>
        </tr>
        <tr>
            <td>Nama Aslab: </td>
            <td><b>
                        <?php echo $nama ?>
                </b></td>
        </tr>
        <tr>
            <td>Jurusan Anda Adalah</td>
            <td><b>
                    <font color=red><?php echo $prodi ?></font>
                </b></td>
        </tr>
    </table>
    <?php
    echo "<button onclick=\"window.location.href='/tugas1web/inputtugas.php'\">Ahmad Ilham Kushartanto</button>";
}
;
?>
    </body>
</html>