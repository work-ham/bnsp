<html>
<!-- Nama : Ahmad Ilham Kushartanto
    NPM: 207064516072
    Prodi: Informatika-->

<body>
    <FORM ACTION="prosestugas.php" METHOD="POST" NAME="input">
        Nama : Ahmad Ilham Kushartanto<br>
        NPM: 207064516072<br>
        Prodi: Informatika <br><br>
        <table border='0' id=results>
            <tr>
                <td><b>Tugas 1 Pemrograman WEB:</b></td>
            </tr>
            <table border='0'>
            <tr>
                <td>Nama lab: </td>
                <td><select name="lab">
                        <option value="CVM">CVM</option>
                        <option value="Network">Network</option>
                        <option value="E-commerce">E-commerce</option>
                    </select></td>
            </tr>
            <tr>
                <td>Nama Aslab: </td>
                <td><input type="text" name="aslab"></td><br>
            </tr>
            <tr>
                <td>Prodi: </td>
                <td><input type="radio" name="prodi" value="TI" checked>
                    TI <br>
                    <input type="radio" name="prodi" value="SI"> SI
                </td>
            </tr>
        </table>
        </table>
        <input type="submit" name="submit" value="submit">

    </FORM>
</body>

</html>